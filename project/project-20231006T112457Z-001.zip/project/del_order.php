<?php
$id = $_GET['id'];
// 1. db connect 
include ("db_conection.php");
// sql to delete a record
$sql = "DELETE FROM food_order WHERE food_order.id=$id";

if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

</body>
</html>